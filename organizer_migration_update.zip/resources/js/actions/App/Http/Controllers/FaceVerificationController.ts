import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FaceVerificationController::show
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/register/verify-face',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FaceVerificationController::show
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FaceVerificationController::show
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::show
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::show
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::show
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::show
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
export const verifyFace = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyFace.url(options),
    method: 'post',
})

verifyFace.definition = {
    methods: ["post"],
    url: '/register/verify-face',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
verifyFace.url = (options?: RouteQueryOptions) => {
    return verifyFace.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
verifyFace.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyFace.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
const verifyFaceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyFace.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
verifyFaceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyFace.url(options),
    method: 'post',
})

verifyFace.form = verifyFaceForm

const FaceVerificationController = { show, verifyFace }

export default FaceVerificationController