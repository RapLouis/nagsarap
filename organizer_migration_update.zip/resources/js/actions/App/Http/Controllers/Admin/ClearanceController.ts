import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ClearanceController::index
* @see app/Http/Controllers/Admin/ClearanceController.php:17
* @route '/admin/clearance'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/clearance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ClearanceController::index
* @see app/Http/Controllers/Admin/ClearanceController.php:17
* @route '/admin/clearance'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ClearanceController::index
* @see app/Http/Controllers/Admin/ClearanceController.php:17
* @route '/admin/clearance'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ClearanceController::index
* @see app/Http/Controllers/Admin/ClearanceController.php:17
* @route '/admin/clearance'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\ClearanceController::index
* @see app/Http/Controllers/Admin/ClearanceController.php:17
* @route '/admin/clearance'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ClearanceController::index
* @see app/Http/Controllers/Admin/ClearanceController.php:17
* @route '/admin/clearance'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ClearanceController::index
* @see app/Http/Controllers/Admin/ClearanceController.php:17
* @route '/admin/clearance'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\ClearanceController::updateStatus
* @see app/Http/Controllers/Admin/ClearanceController.php:97
* @route '/admin/clearance/{clearance}/status'
*/
export const updateStatus = (args: { clearance: number | { clearance_id: number } } | [clearance: number | { clearance_id: number } ] | number | { clearance_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/admin/clearance/{clearance}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\ClearanceController::updateStatus
* @see app/Http/Controllers/Admin/ClearanceController.php:97
* @route '/admin/clearance/{clearance}/status'
*/
updateStatus.url = (args: { clearance: number | { clearance_id: number } } | [clearance: number | { clearance_id: number } ] | number | { clearance_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clearance: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'clearance_id' in args) {
        args = { clearance: args.clearance_id }
    }

    if (Array.isArray(args)) {
        args = {
            clearance: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        clearance: typeof args.clearance === 'object'
        ? args.clearance.clearance_id
        : args.clearance,
    }

    return updateStatus.definition.url
            .replace('{clearance}', parsedArgs.clearance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ClearanceController::updateStatus
* @see app/Http/Controllers/Admin/ClearanceController.php:97
* @route '/admin/clearance/{clearance}/status'
*/
updateStatus.patch = (args: { clearance: number | { clearance_id: number } } | [clearance: number | { clearance_id: number } ] | number | { clearance_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\ClearanceController::updateStatus
* @see app/Http/Controllers/Admin/ClearanceController.php:97
* @route '/admin/clearance/{clearance}/status'
*/
const updateStatusForm = (args: { clearance: number | { clearance_id: number } } | [clearance: number | { clearance_id: number } ] | number | { clearance_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\ClearanceController::updateStatus
* @see app/Http/Controllers/Admin/ClearanceController.php:97
* @route '/admin/clearance/{clearance}/status'
*/
updateStatusForm.patch = (args: { clearance: number | { clearance_id: number } } | [clearance: number | { clearance_id: number } ] | number | { clearance_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateStatus.form = updateStatusForm

const ClearanceController = { index, updateStatus }

export default ClearanceController