import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AnalyticsController::index
* @see app/Http/Controllers/Admin/AnalyticsController.php:20
* @route '/admin/analytics'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::index
* @see app/Http/Controllers/Admin/AnalyticsController.php:20
* @route '/admin/analytics'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::index
* @see app/Http/Controllers/Admin/AnalyticsController.php:20
* @route '/admin/analytics'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::index
* @see app/Http/Controllers/Admin/AnalyticsController.php:20
* @route '/admin/analytics'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::index
* @see app/Http/Controllers/Admin/AnalyticsController.php:20
* @route '/admin/analytics'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::index
* @see app/Http/Controllers/Admin/AnalyticsController.php:20
* @route '/admin/analytics'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::index
* @see app/Http/Controllers/Admin/AnalyticsController.php:20
* @route '/admin/analytics'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::showEvent
* @see app/Http/Controllers/Admin/AnalyticsController.php:317
* @route '/admin/analytics/events/{event}'
*/
export const showEvent = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showEvent.url(args, options),
    method: 'get',
})

showEvent.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/events/{event}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::showEvent
* @see app/Http/Controllers/Admin/AnalyticsController.php:317
* @route '/admin/analytics/events/{event}'
*/
showEvent.url = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'event_id' in args) {
        args = { event: args.event_id }
    }

    if (Array.isArray(args)) {
        args = {
            event: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        event: typeof args.event === 'object'
        ? args.event.event_id
        : args.event,
    }

    return showEvent.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::showEvent
* @see app/Http/Controllers/Admin/AnalyticsController.php:317
* @route '/admin/analytics/events/{event}'
*/
showEvent.get = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showEvent.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::showEvent
* @see app/Http/Controllers/Admin/AnalyticsController.php:317
* @route '/admin/analytics/events/{event}'
*/
showEvent.head = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showEvent.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::showEvent
* @see app/Http/Controllers/Admin/AnalyticsController.php:317
* @route '/admin/analytics/events/{event}'
*/
const showEventForm = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showEvent.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::showEvent
* @see app/Http/Controllers/Admin/AnalyticsController.php:317
* @route '/admin/analytics/events/{event}'
*/
showEventForm.get = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showEvent.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AnalyticsController::showEvent
* @see app/Http/Controllers/Admin/AnalyticsController.php:317
* @route '/admin/analytics/events/{event}'
*/
showEventForm.head = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showEvent.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showEvent.form = showEventForm

const AnalyticsController = { index, showEvent }

export default AnalyticsController