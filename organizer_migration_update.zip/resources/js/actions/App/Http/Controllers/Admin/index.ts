import AdminDashboardController from './AdminDashboardController'
import StudentManagementController from './StudentManagementController'
import ClearanceController from './ClearanceController'
import AdminEventApprovalController from './AdminEventApprovalController'
import AnalyticsController from './AnalyticsController'

const Admin = {
    AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
    StudentManagementController: Object.assign(StudentManagementController, StudentManagementController),
    ClearanceController: Object.assign(ClearanceController, ClearanceController),
    AdminEventApprovalController: Object.assign(AdminEventApprovalController, AdminEventApprovalController),
    AnalyticsController: Object.assign(AnalyticsController, AnalyticsController),
}

export default Admin