import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Organizer\OrganizerDashboardController::index
* @see app/Http/Controllers/Organizer/OrganizerDashboardController.php:14
* @route '/organizer/dashboard'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/organizer/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Organizer\OrganizerDashboardController::index
* @see app/Http/Controllers/Organizer/OrganizerDashboardController.php:14
* @route '/organizer/dashboard'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\OrganizerDashboardController::index
* @see app/Http/Controllers/Organizer/OrganizerDashboardController.php:14
* @route '/organizer/dashboard'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\OrganizerDashboardController::index
* @see app/Http/Controllers/Organizer/OrganizerDashboardController.php:14
* @route '/organizer/dashboard'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Organizer\OrganizerDashboardController::index
* @see app/Http/Controllers/Organizer/OrganizerDashboardController.php:14
* @route '/organizer/dashboard'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\OrganizerDashboardController::index
* @see app/Http/Controllers/Organizer/OrganizerDashboardController.php:14
* @route '/organizer/dashboard'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\OrganizerDashboardController::index
* @see app/Http/Controllers/Organizer/OrganizerDashboardController.php:14
* @route '/organizer/dashboard'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const OrganizerDashboardController = { index }

export default OrganizerDashboardController