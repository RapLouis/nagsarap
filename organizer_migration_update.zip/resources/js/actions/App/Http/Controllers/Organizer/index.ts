import OrganizerDashboardController from './OrganizerDashboardController'
import OrganizerEventController from './OrganizerEventController'
import KioskController from './KioskController'

const Organizer = {
    OrganizerDashboardController: Object.assign(OrganizerDashboardController, OrganizerDashboardController),
    OrganizerEventController: Object.assign(OrganizerEventController, OrganizerEventController),
    KioskController: Object.assign(KioskController, KioskController),
}

export default Organizer