import Api from './Api'
import Admin from './Admin'
import EventController from './EventController'
import Organizer from './Organizer'
import FaceVerificationController from './FaceVerificationController'
import AttendanceController from './AttendanceController'
import Settings from './Settings'

const Controllers = {
    Api: Object.assign(Api, Api),
    Admin: Object.assign(Admin, Admin),
    EventController: Object.assign(EventController, EventController),
    Organizer: Object.assign(Organizer, Organizer),
    FaceVerificationController: Object.assign(FaceVerificationController, FaceVerificationController),
    AttendanceController: Object.assign(AttendanceController, AttendanceController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers