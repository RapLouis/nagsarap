import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AttendanceController::markAttendance
* @see app/Http/Controllers/AttendanceController.php:23
* @route '/attendance/check-in'
*/
export const markAttendance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAttendance.url(options),
    method: 'post',
})

markAttendance.definition = {
    methods: ["post"],
    url: '/attendance/check-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttendanceController::markAttendance
* @see app/Http/Controllers/AttendanceController.php:23
* @route '/attendance/check-in'
*/
markAttendance.url = (options?: RouteQueryOptions) => {
    return markAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::markAttendance
* @see app/Http/Controllers/AttendanceController.php:23
* @route '/attendance/check-in'
*/
markAttendance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAttendance.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AttendanceController::markAttendance
* @see app/Http/Controllers/AttendanceController.php:23
* @route '/attendance/check-in'
*/
const markAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAttendance.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AttendanceController::markAttendance
* @see app/Http/Controllers/AttendanceController.php:23
* @route '/attendance/check-in'
*/
markAttendanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAttendance.url(options),
    method: 'post',
})

markAttendance.form = markAttendanceForm

const AttendanceController = { markAttendance }

export default AttendanceController