import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RegistrationController::register
* @see app/Http/Controllers/Api/RegistrationController.php:42
* @route '/api/v1/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/api/v1/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RegistrationController::register
* @see app/Http/Controllers/Api/RegistrationController.php:42
* @route '/api/v1/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RegistrationController::register
* @see app/Http/Controllers/Api/RegistrationController.php:42
* @route '/api/v1/register'
*/
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::register
* @see app/Http/Controllers/Api/RegistrationController.php:42
* @route '/api/v1/register'
*/
const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: register.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::register
* @see app/Http/Controllers/Api/RegistrationController.php:42
* @route '/api/v1/register'
*/
registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: register.url(options),
    method: 'post',
})

register.form = registerForm

/**
* @see \App\Http\Controllers\Api\RegistrationController::validatePhoto
* @see app/Http/Controllers/Api/RegistrationController.php:16
* @route '/api/v1/register/validate-photo'
*/
export const validatePhoto = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validatePhoto.url(options),
    method: 'post',
})

validatePhoto.definition = {
    methods: ["post"],
    url: '/api/v1/register/validate-photo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RegistrationController::validatePhoto
* @see app/Http/Controllers/Api/RegistrationController.php:16
* @route '/api/v1/register/validate-photo'
*/
validatePhoto.url = (options?: RouteQueryOptions) => {
    return validatePhoto.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RegistrationController::validatePhoto
* @see app/Http/Controllers/Api/RegistrationController.php:16
* @route '/api/v1/register/validate-photo'
*/
validatePhoto.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validatePhoto.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::validatePhoto
* @see app/Http/Controllers/Api/RegistrationController.php:16
* @route '/api/v1/register/validate-photo'
*/
const validatePhotoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validatePhoto.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::validatePhoto
* @see app/Http/Controllers/Api/RegistrationController.php:16
* @route '/api/v1/register/validate-photo'
*/
validatePhotoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validatePhoto.url(options),
    method: 'post',
})

validatePhoto.form = validatePhotoForm

/**
* @see \App\Http\Controllers\Api\RegistrationController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/RegistrationController.php:72
* @route '/api/v1/register/analyze-liveness-frame'
*/
export const analyzeLivenessFrame = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyzeLivenessFrame.url(options),
    method: 'post',
})

analyzeLivenessFrame.definition = {
    methods: ["post"],
    url: '/api/v1/register/analyze-liveness-frame',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RegistrationController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/RegistrationController.php:72
* @route '/api/v1/register/analyze-liveness-frame'
*/
analyzeLivenessFrame.url = (options?: RouteQueryOptions) => {
    return analyzeLivenessFrame.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RegistrationController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/RegistrationController.php:72
* @route '/api/v1/register/analyze-liveness-frame'
*/
analyzeLivenessFrame.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyzeLivenessFrame.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/RegistrationController.php:72
* @route '/api/v1/register/analyze-liveness-frame'
*/
const analyzeLivenessFrameForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: analyzeLivenessFrame.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/RegistrationController.php:72
* @route '/api/v1/register/analyze-liveness-frame'
*/
analyzeLivenessFrameForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: analyzeLivenessFrame.url(options),
    method: 'post',
})

analyzeLivenessFrame.form = analyzeLivenessFrameForm

/**
* @see \App\Http\Controllers\Api\RegistrationController::verifyFace
* @see app/Http/Controllers/Api/RegistrationController.php:95
* @route '/api/v1/register/verify-face'
*/
export const verifyFace = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyFace.url(options),
    method: 'post',
})

verifyFace.definition = {
    methods: ["post"],
    url: '/api/v1/register/verify-face',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RegistrationController::verifyFace
* @see app/Http/Controllers/Api/RegistrationController.php:95
* @route '/api/v1/register/verify-face'
*/
verifyFace.url = (options?: RouteQueryOptions) => {
    return verifyFace.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RegistrationController::verifyFace
* @see app/Http/Controllers/Api/RegistrationController.php:95
* @route '/api/v1/register/verify-face'
*/
verifyFace.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyFace.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::verifyFace
* @see app/Http/Controllers/Api/RegistrationController.php:95
* @route '/api/v1/register/verify-face'
*/
const verifyFaceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyFace.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\RegistrationController::verifyFace
* @see app/Http/Controllers/Api/RegistrationController.php:95
* @route '/api/v1/register/verify-face'
*/
verifyFaceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyFace.url(options),
    method: 'post',
})

verifyFace.form = verifyFaceForm

const RegistrationController = { register, validatePhoto, analyzeLivenessFrame, verifyFace }

export default RegistrationController