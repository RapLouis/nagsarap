import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\WebVerificationController::create
* @see app/Http/Controllers/Api/WebVerificationController.php:9
* @route '/api/v1/register/web-verification-url'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/api/v1/register/web-verification-url',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\WebVerificationController::create
* @see app/Http/Controllers/Api/WebVerificationController.php:9
* @route '/api/v1/register/web-verification-url'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WebVerificationController::create
* @see app/Http/Controllers/Api/WebVerificationController.php:9
* @route '/api/v1/register/web-verification-url'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WebVerificationController::create
* @see app/Http/Controllers/Api/WebVerificationController.php:9
* @route '/api/v1/register/web-verification-url'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\WebVerificationController::create
* @see app/Http/Controllers/Api/WebVerificationController.php:9
* @route '/api/v1/register/web-verification-url'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WebVerificationController::create
* @see app/Http/Controllers/Api/WebVerificationController.php:9
* @route '/api/v1/register/web-verification-url'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WebVerificationController::create
* @see app/Http/Controllers/Api/WebVerificationController.php:9
* @route '/api/v1/register/web-verification-url'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

const WebVerificationController = { create }

export default WebVerificationController