import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\FaceChallengeController::registration
* @see app/Http/Controllers/Api/FaceChallengeController.php:12
* @route '/api/v1/register/liveness-challenge'
*/
export const registration = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registration.url(options),
    method: 'post',
})

registration.definition = {
    methods: ["post"],
    url: '/api/v1/register/liveness-challenge',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::registration
* @see app/Http/Controllers/Api/FaceChallengeController.php:12
* @route '/api/v1/register/liveness-challenge'
*/
registration.url = (options?: RouteQueryOptions) => {
    return registration.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::registration
* @see app/Http/Controllers/Api/FaceChallengeController.php:12
* @route '/api/v1/register/liveness-challenge'
*/
registration.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registration.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::registration
* @see app/Http/Controllers/Api/FaceChallengeController.php:12
* @route '/api/v1/register/liveness-challenge'
*/
const registrationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: registration.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::registration
* @see app/Http/Controllers/Api/FaceChallengeController.php:12
* @route '/api/v1/register/liveness-challenge'
*/
registrationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: registration.url(options),
    method: 'post',
})

registration.form = registrationForm

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::attendance
* @see app/Http/Controllers/Api/FaceChallengeController.php:40
* @route '/api/v1/attendance/liveness-challenge'
*/
export const attendance = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: attendance.url(options),
    method: 'post',
})

attendance.definition = {
    methods: ["post"],
    url: '/api/v1/attendance/liveness-challenge',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::attendance
* @see app/Http/Controllers/Api/FaceChallengeController.php:40
* @route '/api/v1/attendance/liveness-challenge'
*/
attendance.url = (options?: RouteQueryOptions) => {
    return attendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::attendance
* @see app/Http/Controllers/Api/FaceChallengeController.php:40
* @route '/api/v1/attendance/liveness-challenge'
*/
attendance.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: attendance.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::attendance
* @see app/Http/Controllers/Api/FaceChallengeController.php:40
* @route '/api/v1/attendance/liveness-challenge'
*/
const attendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: attendance.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FaceChallengeController::attendance
* @see app/Http/Controllers/Api/FaceChallengeController.php:40
* @route '/api/v1/attendance/liveness-challenge'
*/
attendanceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: attendance.url(options),
    method: 'post',
})

attendance.form = attendanceForm

const FaceChallengeController = { registration, attendance }

export default FaceChallengeController