import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\EventController::index
* @see app/Http/Controllers/Api/EventController.php:12
* @route '/api/v1/events'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\EventController::index
* @see app/Http/Controllers/Api/EventController.php:12
* @route '/api/v1/events'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EventController::index
* @see app/Http/Controllers/Api/EventController.php:12
* @route '/api/v1/events'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EventController::index
* @see app/Http/Controllers/Api/EventController.php:12
* @route '/api/v1/events'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\EventController::index
* @see app/Http/Controllers/Api/EventController.php:12
* @route '/api/v1/events'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EventController::index
* @see app/Http/Controllers/Api/EventController.php:12
* @route '/api/v1/events'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EventController::index
* @see app/Http/Controllers/Api/EventController.php:12
* @route '/api/v1/events'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\EventController::show
* @see app/Http/Controllers/Api/EventController.php:28
* @route '/api/v1/events/{event}'
*/
export const show = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/events/{event}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\EventController::show
* @see app/Http/Controllers/Api/EventController.php:28
* @route '/api/v1/events/{event}'
*/
show.url = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'event_id' in args) {
        args = { event: args.event_id }
    }

    if (Array.isArray(args)) {
        args = {
            event: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        event: typeof args.event === 'object'
        ? args.event.event_id
        : args.event,
    }

    return show.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EventController::show
* @see app/Http/Controllers/Api/EventController.php:28
* @route '/api/v1/events/{event}'
*/
show.get = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EventController::show
* @see app/Http/Controllers/Api/EventController.php:28
* @route '/api/v1/events/{event}'
*/
show.head = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\EventController::show
* @see app/Http/Controllers/Api/EventController.php:28
* @route '/api/v1/events/{event}'
*/
const showForm = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EventController::show
* @see app/Http/Controllers/Api/EventController.php:28
* @route '/api/v1/events/{event}'
*/
showForm.get = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EventController::show
* @see app/Http/Controllers/Api/EventController.php:28
* @route '/api/v1/events/{event}'
*/
showForm.head = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const EventController = { index, show }

export default EventController