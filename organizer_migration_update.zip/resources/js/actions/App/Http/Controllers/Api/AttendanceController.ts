import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AttendanceController::history
* @see app/Http/Controllers/Api/AttendanceController.php:350
* @route '/api/v1/attendance/history'
*/
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/api/v1/attendance/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::history
* @see app/Http/Controllers/Api/AttendanceController.php:350
* @route '/api/v1/attendance/history'
*/
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::history
* @see app/Http/Controllers/Api/AttendanceController.php:350
* @route '/api/v1/attendance/history'
*/
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::history
* @see app/Http/Controllers/Api/AttendanceController.php:350
* @route '/api/v1/attendance/history'
*/
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::history
* @see app/Http/Controllers/Api/AttendanceController.php:350
* @route '/api/v1/attendance/history'
*/
const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::history
* @see app/Http/Controllers/Api/AttendanceController.php:350
* @route '/api/v1/attendance/history'
*/
historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::history
* @see app/Http/Controllers/Api/AttendanceController.php:350
* @route '/api/v1/attendance/history'
*/
historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

history.form = historyForm

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
* @see app/Http/Controllers/Api/AttendanceController.php:391
* @route '/api/v1/attendance/check-in'
*/
export const checkIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(options),
    method: 'post',
})

checkIn.definition = {
    methods: ["post"],
    url: '/api/v1/attendance/check-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
* @see app/Http/Controllers/Api/AttendanceController.php:391
* @route '/api/v1/attendance/check-in'
*/
checkIn.url = (options?: RouteQueryOptions) => {
    return checkIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
* @see app/Http/Controllers/Api/AttendanceController.php:391
* @route '/api/v1/attendance/check-in'
*/
checkIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
* @see app/Http/Controllers/Api/AttendanceController.php:391
* @route '/api/v1/attendance/check-in'
*/
const checkInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: checkIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
* @see app/Http/Controllers/Api/AttendanceController.php:391
* @route '/api/v1/attendance/check-in'
*/
checkInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: checkIn.url(options),
    method: 'post',
})

checkIn.form = checkInForm

/**
* @see \App\Http\Controllers\Api\AttendanceController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/AttendanceController.php:19
* @route '/api/v1/attendance/analyze-liveness-frame'
*/
export const analyzeLivenessFrame = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyzeLivenessFrame.url(options),
    method: 'post',
})

analyzeLivenessFrame.definition = {
    methods: ["post"],
    url: '/api/v1/attendance/analyze-liveness-frame',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/AttendanceController.php:19
* @route '/api/v1/attendance/analyze-liveness-frame'
*/
analyzeLivenessFrame.url = (options?: RouteQueryOptions) => {
    return analyzeLivenessFrame.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/AttendanceController.php:19
* @route '/api/v1/attendance/analyze-liveness-frame'
*/
analyzeLivenessFrame.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyzeLivenessFrame.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/AttendanceController.php:19
* @route '/api/v1/attendance/analyze-liveness-frame'
*/
const analyzeLivenessFrameForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: analyzeLivenessFrame.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::analyzeLivenessFrame
* @see app/Http/Controllers/Api/AttendanceController.php:19
* @route '/api/v1/attendance/analyze-liveness-frame'
*/
analyzeLivenessFrameForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: analyzeLivenessFrame.url(options),
    method: 'post',
})

analyzeLivenessFrame.form = analyzeLivenessFrameForm

/**
* @see \App\Http\Controllers\Api\AttendanceController::mobileCheckIn
* @see app/Http/Controllers/Api/AttendanceController.php:43
* @route '/api/v1/attendance/mobile-check-in'
*/
export const mobileCheckIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mobileCheckIn.url(options),
    method: 'post',
})

mobileCheckIn.definition = {
    methods: ["post"],
    url: '/api/v1/attendance/mobile-check-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::mobileCheckIn
* @see app/Http/Controllers/Api/AttendanceController.php:43
* @route '/api/v1/attendance/mobile-check-in'
*/
mobileCheckIn.url = (options?: RouteQueryOptions) => {
    return mobileCheckIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::mobileCheckIn
* @see app/Http/Controllers/Api/AttendanceController.php:43
* @route '/api/v1/attendance/mobile-check-in'
*/
mobileCheckIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mobileCheckIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::mobileCheckIn
* @see app/Http/Controllers/Api/AttendanceController.php:43
* @route '/api/v1/attendance/mobile-check-in'
*/
const mobileCheckInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mobileCheckIn.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::mobileCheckIn
* @see app/Http/Controllers/Api/AttendanceController.php:43
* @route '/api/v1/attendance/mobile-check-in'
*/
mobileCheckInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mobileCheckIn.url(options),
    method: 'post',
})

mobileCheckIn.form = mobileCheckInForm

/**
* @see \App\Http\Controllers\Api\AttendanceController::sync
* @see app/Http/Controllers/Api/AttendanceController.php:264
* @route '/api/v1/attendance/sync'
*/
export const sync = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/api/v1/attendance/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::sync
* @see app/Http/Controllers/Api/AttendanceController.php:264
* @route '/api/v1/attendance/sync'
*/
sync.url = (options?: RouteQueryOptions) => {
    return sync.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::sync
* @see app/Http/Controllers/Api/AttendanceController.php:264
* @route '/api/v1/attendance/sync'
*/
sync.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::sync
* @see app/Http/Controllers/Api/AttendanceController.php:264
* @route '/api/v1/attendance/sync'
*/
const syncForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sync.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AttendanceController::sync
* @see app/Http/Controllers/Api/AttendanceController.php:264
* @route '/api/v1/attendance/sync'
*/
syncForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sync.url(options),
    method: 'post',
})

sync.form = syncForm

const AttendanceController = { history, checkIn, analyzeLivenessFrame, mobileCheckIn, sync }

export default AttendanceController