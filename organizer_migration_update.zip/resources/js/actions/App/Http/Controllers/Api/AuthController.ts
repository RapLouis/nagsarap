import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AuthController::login
* @see app/Http/Controllers/Api/AuthController.php:14
* @route '/api/v1/auth/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/v1/auth/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::login
* @see app/Http/Controllers/Api/AuthController.php:14
* @route '/api/v1/auth/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::login
* @see app/Http/Controllers/Api/AuthController.php:14
* @route '/api/v1/auth/login'
*/
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::login
* @see app/Http/Controllers/Api/AuthController.php:14
* @route '/api/v1/auth/login'
*/
const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: login.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::login
* @see app/Http/Controllers/Api/AuthController.php:14
* @route '/api/v1/auth/login'
*/
loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: login.url(options),
    method: 'post',
})

login.form = loginForm

/**
* @see \App\Http\Controllers\Api\AuthController::me
* @see app/Http/Controllers/Api/AuthController.php:25
* @route '/api/v1/me'
*/
export const me = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

me.definition = {
    methods: ["get","head"],
    url: '/api/v1/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::me
* @see app/Http/Controllers/Api/AuthController.php:25
* @route '/api/v1/me'
*/
me.url = (options?: RouteQueryOptions) => {
    return me.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::me
* @see app/Http/Controllers/Api/AuthController.php:25
* @route '/api/v1/me'
*/
me.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::me
* @see app/Http/Controllers/Api/AuthController.php:25
* @route '/api/v1/me'
*/
me.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AuthController::me
* @see app/Http/Controllers/Api/AuthController.php:25
* @route '/api/v1/me'
*/
const meForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: me.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::me
* @see app/Http/Controllers/Api/AuthController.php:25
* @route '/api/v1/me'
*/
meForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: me.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::me
* @see app/Http/Controllers/Api/AuthController.php:25
* @route '/api/v1/me'
*/
meForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: me.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

me.form = meForm

/**
* @see \App\Http\Controllers\Api\AuthController::profilePhoto
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
export const profilePhoto = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profilePhoto.url(options),
    method: 'get',
})

profilePhoto.definition = {
    methods: ["get","head"],
    url: '/api/v1/me/photo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::profilePhoto
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
profilePhoto.url = (options?: RouteQueryOptions) => {
    return profilePhoto.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::profilePhoto
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
profilePhoto.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profilePhoto.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::profilePhoto
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
profilePhoto.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profilePhoto.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AuthController::profilePhoto
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
const profilePhotoForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profilePhoto.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::profilePhoto
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
profilePhotoForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profilePhoto.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::profilePhoto
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
profilePhotoForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profilePhoto.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profilePhoto.form = profilePhotoForm

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:38
* @route '/api/v1/auth/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/v1/auth/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:38
* @route '/api/v1/auth/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:38
* @route '/api/v1/auth/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:38
* @route '/api/v1/auth/logout'
*/
const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:38
* @route '/api/v1/auth/logout'
*/
logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

logout.form = logoutForm

const AuthController = { login, me, profilePhoto, logout }

export default AuthController