import AuthController from './AuthController'
import RegistrationController from './RegistrationController'
import FaceChallengeController from './FaceChallengeController'
import WebVerificationController from './WebVerificationController'
import EventController from './EventController'
import AttendanceController from './AttendanceController'
import SanctionController from './SanctionController'
import NotificationController from './NotificationController'

const Api = {
    AuthController: Object.assign(AuthController, AuthController),
    RegistrationController: Object.assign(RegistrationController, RegistrationController),
    FaceChallengeController: Object.assign(FaceChallengeController, FaceChallengeController),
    WebVerificationController: Object.assign(WebVerificationController, WebVerificationController),
    EventController: Object.assign(EventController, EventController),
    AttendanceController: Object.assign(AttendanceController, AttendanceController),
    SanctionController: Object.assign(SanctionController, SanctionController),
    NotificationController: Object.assign(NotificationController, NotificationController),
}

export default Api