import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Head } from '@inertiajs/react';
import OrganizerLayout from '@/layouts/organizer-layout';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { CheckCircle2, AlertCircle, Camera, RefreshCw } from 'lucide-react';

interface Event {
  id: number;
  title: string;
}

interface StudentResult {
  name: string;
  student_number: string;
  course: string;
}

export default function Kiosk({ events }: { events: Event[] }) {
  const [selectedEventId, setSelectedEventId] = useState<number>(events[0]?.id || 0);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [step, setStep] = useState<'look' | 'turn' | 'verifying'>('look');
  const [challengeDirection, setChallengeDirection] = useState<'turn_left' | 'turn_right'>('turn_left');
  const [modalResult, setModalResult] = useState<{
    open: boolean;
    success: boolean;
    message: string;
    student?: StudentResult;
    time_in?: string;
  }>({ open: false, success: false, message: '' });

  useEffect(() => {
    let stream: MediaStream | null = null;
    navigator.mediaDevices
      .getUserMedia({ video: { width: 1280, height: 720, facingMode: 'user' } })
      .then((s) => {
        stream = s;
        if (videoRef.current) {
          videoRef.current.srcObject = s;
        }
      })
      .catch((err) => console.error('Kiosk camera init error:', err));

    return () => {
      if (stream) stream.getTracks().forEach((track) => track.stop());
    };
  }, []);

  const promptNextStudent = useCallback(() => {
    const directions: Array<'turn_left' | 'turn_right'> = ['turn_left', 'turn_right'];
    setChallengeDirection(directions[Math.floor(Math.random() * directions.length)]);
    setStep('look');
  }, []);

  const executeVerification = async () => {
    if (!videoRef.current || !canvasRef.current || !selectedEventId) return;

    setStep('verifying');
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const base64Image = canvas.toDataURL('image/jpeg', 0.85);

    try {
      const response = await fetch('/organizer/kiosk/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': (document.querySelector('meta[name="csrf-token"]') as HTMLMetaElement)?.content || '',
        },
        body: JSON.stringify({
          event_id: selectedEventId,
          image: base64Image,
          challenge_gesture: challengeDirection,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setModalResult({
          open: true,
          success: true,
          message: 'Attendance Logged Successfully!',
          student: data.student,
          time_in: data.time_in,
        });
      } else {
        throw new Error(data.message || 'Verification Failed');
      }
    } catch (error: any) {
      setModalResult({
        open: true,
        success: false,
        message: error.message || 'Verification Failed. Face not recognized.',
      });
    }

    setTimeout(() => {
      setModalResult((prev) => ({ ...prev, open: false }));
      promptNextStudent();
    }, 2500);
  };

  return (
    <OrganizerLayout title="Facial Recognition Kiosk">
      <Head title="Attendance Kiosk" />

      <div className="flex flex-col h-[calc(100vh-8rem)] bg-slate-950 text-white rounded-2xl overflow-hidden shadow-xl border border-slate-800 p-6 select-none">
        {/* Header bar */}
        <div className="flex justify-between items-center bg-slate-900/80 backdrop-blur p-4 rounded-xl border border-slate-800 mb-4">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
              <Camera className="text-blue-500 w-5 h-5" /> Live Kiosk Feed
            </h2>
            <p className="text-xs text-slate-400">Position face inside camera guide frame</p>
          </div>

          <select
            value={selectedEventId}
            onChange={(e) => setSelectedEventId(Number(e.target.value))}
            className="bg-slate-800 border-slate-700 text-sm text-white rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
          >
            {events.map((event) => (
              <option key={event.id} value={event.id}>
                {event.title}
              </option>
            ))}
          </select>
        </div>

        {/* Camera Viewport */}
        <div className="relative flex-1 flex items-center justify-center overflow-hidden rounded-xl border border-slate-800 bg-black">
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover transform -scale-x-100" />
          <canvas ref={canvasRef} className="hidden" />

          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
            <div className="w-72 h-96 border-2 border-dashed border-blue-400/60 rounded-full animate-pulse flex items-center justify-center">
              <div className="w-64 h-88 border border-blue-500/30 rounded-full" />
            </div>

            <div className="absolute bottom-6 bg-slate-900/90 border border-slate-700/80 px-6 py-3 rounded-full shadow-2xl backdrop-blur text-center">
              {step === 'look' && (
                <p className="text-base font-semibold text-blue-400">1. Look straight into camera</p>
              )}
              {step === 'turn' && (
                <p className="text-base font-semibold text-amber-400">
                  2. Turn head slightly {challengeDirection === 'turn_left' ? 'LEFT' : 'RIGHT'}
                </p>
              )}
              {step === 'verifying' && (
                <p className="text-base font-semibold text-green-400 flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin" /> Verifying biometrics...
                </p>
              )}
            </div>
          </div>

          <div className="absolute right-6 bottom-6 flex flex-col gap-2">
            {step === 'look' && (
              <button
                onClick={() => setStep('turn')}
                className="bg-blue-600 hover:bg-blue-500 px-5 py-2.5 rounded-lg font-medium text-sm shadow-lg transition"
              >
                Face Aligned → Next
              </button>
            )}
            {step === 'turn' && (
              <button
                onClick={executeVerification}
                className="bg-green-600 hover:bg-green-500 px-5 py-2.5 rounded-lg font-medium text-sm shadow-lg transition"
              >
                Confirm Pose & Check-In
              </button>
            )}
          </div>
        </div>

        {/* Pop-up Outcome Modal */}
        <Dialog open={modalResult.open} onOpenChange={(open) => setModalResult((prev) => ({ ...prev, open }))}>
          <DialogContent className="sm:max-w-md border-slate-800 bg-slate-900 text-white text-center p-8">
            {modalResult.success ? (
              <div className="flex flex-col items-center space-y-3">
                <CheckCircle2 className="w-16 h-16 text-green-500 animate-bounce" />
                <h2 className="text-2xl font-bold text-white">Welcome!</h2>
                {modalResult.student && (
                  <div className="space-y-1">
                    <p className="text-lg font-semibold text-blue-400">{modalResult.student.name}</p>
                    <p className="text-xs text-slate-400">{modalResult.student.student_number} • {modalResult.student.course}</p>
                    <p className="text-xs font-mono text-green-400 mt-2">Time In: {modalResult.time_in}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center space-y-3">
                <AlertCircle className="w-16 h-16 text-red-500" />
                <h2 className="text-xl font-bold text-white">Verification Failed</h2>
                <p className="text-sm text-slate-400">{modalResult.message}</p>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </OrganizerLayout>
  );
}