import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import verifyFaceE5d6b3 from './verify-face'
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
* @route '/register'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
* @route '/register'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
* @route '/register'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
* @route '/register'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
* @route '/register'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
export const verifyFace = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyFace.url(options),
    method: 'get',
})

verifyFace.definition = {
    methods: ["get","head"],
    url: '/register/verify-face',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
verifyFace.url = (options?: RouteQueryOptions) => {
    return verifyFace.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
verifyFace.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyFace.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
verifyFace.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyFace.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
const verifyFaceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: verifyFace.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
verifyFaceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: verifyFace.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:32
* @route '/register/verify-face'
*/
verifyFaceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: verifyFace.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

verifyFace.form = verifyFaceForm

const register = {
    store: Object.assign(store, store),
    verifyFace: Object.assign(verifyFace, verifyFaceE5d6b3),
}

export default register