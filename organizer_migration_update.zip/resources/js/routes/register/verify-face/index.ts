import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\FaceVerificationController::submit
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/register/verify-face',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FaceVerificationController::submit
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FaceVerificationController::submit
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::submit
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::submit
* @see app/Http/Controllers/FaceVerificationController.php:59
* @route '/register/verify-face'
*/
submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

submit.form = submitForm

const verifyFace = {
    submit: Object.assign(submit, submit),
}

export default verifyFace