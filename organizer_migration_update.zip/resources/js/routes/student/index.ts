import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:376
* @route '/student/{student}/face-photo'
*/
export const facePhoto = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: facePhoto.url(args, options),
    method: 'get',
})

facePhoto.definition = {
    methods: ["get","head"],
    url: '/student/{student}/face-photo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:376
* @route '/student/{student}/face-photo'
*/
facePhoto.url = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'student_id' in args) {
        args = { student: args.student_id }
    }

    if (Array.isArray(args)) {
        args = {
            student: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        student: typeof args.student === 'object'
        ? args.student.student_id
        : args.student,
    }

    return facePhoto.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:376
* @route '/student/{student}/face-photo'
*/
facePhoto.get = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: facePhoto.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:376
* @route '/student/{student}/face-photo'
*/
facePhoto.head = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: facePhoto.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:376
* @route '/student/{student}/face-photo'
*/
const facePhotoForm = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: facePhoto.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:376
* @route '/student/{student}/face-photo'
*/
facePhotoForm.get = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: facePhoto.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:376
* @route '/student/{student}/face-photo'
*/
facePhotoForm.head = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: facePhoto.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

facePhoto.form = facePhotoForm

const student = {
    facePhoto: Object.assign(facePhoto, facePhoto),
}

export default student