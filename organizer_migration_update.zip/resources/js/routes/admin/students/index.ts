import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\StudentManagementController::index
* @see app/Http/Controllers/Admin/StudentManagementController.php:27
* @route '/admin/students'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::index
* @see app/Http/Controllers/Admin/StudentManagementController.php:27
* @route '/admin/students'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::index
* @see app/Http/Controllers/Admin/StudentManagementController.php:27
* @route '/admin/students'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::index
* @see app/Http/Controllers/Admin/StudentManagementController.php:27
* @route '/admin/students'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::index
* @see app/Http/Controllers/Admin/StudentManagementController.php:27
* @route '/admin/students'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::index
* @see app/Http/Controllers/Admin/StudentManagementController.php:27
* @route '/admin/students'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::index
* @see app/Http/Controllers/Admin/StudentManagementController.php:27
* @route '/admin/students'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::update
* @see app/Http/Controllers/Admin/StudentManagementController.php:105
* @route '/admin/students/{student}'
*/
export const update = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/students/{student}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::update
* @see app/Http/Controllers/Admin/StudentManagementController.php:105
* @route '/admin/students/{student}'
*/
update.url = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'student_id' in args) {
        args = { student: args.student_id }
    }

    if (Array.isArray(args)) {
        args = {
            student: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        student: typeof args.student === 'object'
        ? args.student.student_id
        : args.student,
    }

    return update.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::update
* @see app/Http/Controllers/Admin/StudentManagementController.php:105
* @route '/admin/students/{student}'
*/
update.patch = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::update
* @see app/Http/Controllers/Admin/StudentManagementController.php:105
* @route '/admin/students/{student}'
*/
const updateForm = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::update
* @see app/Http/Controllers/Admin/StudentManagementController.php:105
* @route '/admin/students/{student}'
*/
updateForm.patch = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::verify
* @see app/Http/Controllers/Admin/StudentManagementController.php:113
* @route '/admin/students/{student}/verify'
*/
export const verify = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: verify.url(args, options),
    method: 'patch',
})

verify.definition = {
    methods: ["patch"],
    url: '/admin/students/{student}/verify',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::verify
* @see app/Http/Controllers/Admin/StudentManagementController.php:113
* @route '/admin/students/{student}/verify'
*/
verify.url = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'student_id' in args) {
        args = { student: args.student_id }
    }

    if (Array.isArray(args)) {
        args = {
            student: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        student: typeof args.student === 'object'
        ? args.student.student_id
        : args.student,
    }

    return verify.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::verify
* @see app/Http/Controllers/Admin/StudentManagementController.php:113
* @route '/admin/students/{student}/verify'
*/
verify.patch = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: verify.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::verify
* @see app/Http/Controllers/Admin/StudentManagementController.php:113
* @route '/admin/students/{student}/verify'
*/
const verifyForm = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::verify
* @see app/Http/Controllers/Admin/StudentManagementController.php:113
* @route '/admin/students/{student}/verify'
*/
verifyForm.patch = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

verify.form = verifyForm

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::reject
* @see app/Http/Controllers/Admin/StudentManagementController.php:121
* @route '/admin/students/{student}/reject'
*/
export const reject = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/admin/students/{student}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::reject
* @see app/Http/Controllers/Admin/StudentManagementController.php:121
* @route '/admin/students/{student}/reject'
*/
reject.url = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'student_id' in args) {
        args = { student: args.student_id }
    }

    if (Array.isArray(args)) {
        args = {
            student: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        student: typeof args.student === 'object'
        ? args.student.student_id
        : args.student,
    }

    return reject.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::reject
* @see app/Http/Controllers/Admin/StudentManagementController.php:121
* @route '/admin/students/{student}/reject'
*/
reject.patch = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::reject
* @see app/Http/Controllers/Admin/StudentManagementController.php:121
* @route '/admin/students/{student}/reject'
*/
const rejectForm = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::reject
* @see app/Http/Controllers/Admin/StudentManagementController.php:121
* @route '/admin/students/{student}/reject'
*/
rejectForm.patch = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

reject.form = rejectForm

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::destroy
* @see app/Http/Controllers/Admin/StudentManagementController.php:128
* @route '/admin/students/{student}'
*/
export const destroy = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/students/{student}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::destroy
* @see app/Http/Controllers/Admin/StudentManagementController.php:128
* @route '/admin/students/{student}'
*/
destroy.url = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'student_id' in args) {
        args = { student: args.student_id }
    }

    if (Array.isArray(args)) {
        args = {
            student: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        student: typeof args.student === 'object'
        ? args.student.student_id
        : args.student,
    }

    return destroy.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::destroy
* @see app/Http/Controllers/Admin/StudentManagementController.php:128
* @route '/admin/students/{student}'
*/
destroy.delete = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::destroy
* @see app/Http/Controllers/Admin/StudentManagementController.php:128
* @route '/admin/students/{student}'
*/
const destroyForm = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\StudentManagementController::destroy
* @see app/Http/Controllers/Admin/StudentManagementController.php:128
* @route '/admin/students/{student}'
*/
destroyForm.delete = (args: { student: number | { student_id: number } } | [student: number | { student_id: number } ] | number | { student_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const students = {
    index: Object.assign(index, index),
    update: Object.assign(update, update),
    verify: Object.assign(verify, verify),
    reject: Object.assign(reject, reject),
    destroy: Object.assign(destroy, destroy),
}

export default students