import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:16
* @route '/organizer/kiosk'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/organizer/kiosk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:16
* @route '/organizer/kiosk'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:16
* @route '/organizer/kiosk'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:16
* @route '/organizer/kiosk'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:16
* @route '/organizer/kiosk'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:16
* @route '/organizer/kiosk'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:16
* @route '/organizer/kiosk'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:29
* @route '/organizer/kiosk/verify'
*/
export const verify = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/organizer/kiosk/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:29
* @route '/organizer/kiosk/verify'
*/
verify.url = (options?: RouteQueryOptions) => {
    return verify.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:29
* @route '/organizer/kiosk/verify'
*/
verify.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:29
* @route '/organizer/kiosk/verify'
*/
const verifyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:29
* @route '/organizer/kiosk/verify'
*/
verifyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(options),
    method: 'post',
})

verify.form = verifyForm

const kiosk = {
    index: Object.assign(index, index),
    verify: Object.assign(verify, verify),
}

export default kiosk