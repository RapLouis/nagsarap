import verifyFace from './verify-face'

const register = {
    verifyFace: Object.assign(verifyFace, verifyFace),
}

export default register