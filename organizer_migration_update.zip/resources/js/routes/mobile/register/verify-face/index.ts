import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see routes/web.php:402
* @route '/mobile/register/verify-face/{user}'
*/
export const bridge = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bridge.url(args, options),
    method: 'get',
})

bridge.definition = {
    methods: ["get","head"],
    url: '/mobile/register/verify-face/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:402
* @route '/mobile/register/verify-face/{user}'
*/
bridge.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return bridge.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:402
* @route '/mobile/register/verify-face/{user}'
*/
bridge.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bridge.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:402
* @route '/mobile/register/verify-face/{user}'
*/
bridge.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bridge.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:402
* @route '/mobile/register/verify-face/{user}'
*/
const bridgeForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bridge.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:402
* @route '/mobile/register/verify-face/{user}'
*/
bridgeForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bridge.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:402
* @route '/mobile/register/verify-face/{user}'
*/
bridgeForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bridge.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

bridge.form = bridgeForm

const verifyFace = {
    bridge: Object.assign(bridge, bridge),
}

export default verifyFace