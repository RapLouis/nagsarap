import register from './register'

const mobile = {
    register: Object.assign(register, register),
}

export default mobile