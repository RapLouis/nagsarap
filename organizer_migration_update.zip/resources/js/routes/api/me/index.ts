import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AuthController::photo
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
export const photo = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: photo.url(options),
    method: 'get',
})

photo.definition = {
    methods: ["get","head"],
    url: '/api/v1/me/photo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::photo
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
photo.url = (options?: RouteQueryOptions) => {
    return photo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::photo
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
photo.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: photo.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::photo
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
photo.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: photo.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AuthController::photo
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
const photoForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: photo.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::photo
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
photoForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: photo.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::photo
* @see app/Http/Controllers/Api/AuthController.php:31
* @route '/api/v1/me/photo'
*/
photoForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: photo.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

photo.form = photoForm

const me = {
    photo: Object.assign(photo, photo),
}

export default me