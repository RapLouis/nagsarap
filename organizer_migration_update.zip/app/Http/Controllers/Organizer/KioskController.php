<?php

namespace App\Http\Controllers\Organizer;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Student;
use App\Models\Attendance;
use App\Services\BiometricService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Carbon\Carbon;

class KioskController extends Controller
{
    public function index(Request $request)
    {
        $events = Event::where('user_id', $request->user()->id)
            ->where('status', 'approved')
            ->whereDate('start_date', '<=', Carbon::today())
            ->whereDate('end_date', '>=', Carbon::today())
            ->get();

        return Inertia::render('organizer/Kiosk', [
            'events' => $events,
        ]);
    }

    public function verifyFace(Request $request, BiometricService $biometricService)
    {
        $request->validate([
            'event_id' => 'required|exists:events,id',
            'image' => 'required|string',
        ]);

        $event = Event::where('id', $request->event_id)
            ->where('user_id', $request->user()->id)
            ->firstOrFail();

        $student = $biometricService->findMatchingStudent($request->image);

        if (!$student) {
            return response()->json([
                'success' => false,
                'message' => 'Student record not recognized in database.',
            ], 404);
        }

        $attendance = Attendance::firstOrCreate(
            [
                'student_id' => $student->id,
                'event_id' => $event->id,
                'date' => Carbon::today()->toDateString(),
            ],
            [
                'time_in' => Carbon::now()->toTimeString(),
                'status' => 'present',
                'verification_method' => 'kiosk_face_recognition',
            ]
        );

        return response()->json([
            'success' => true,
            'message' => 'Attendance logged successfully!',
            'student' => [
                'name' => $student->name,
                'student_number' => $student->student_number,
                'course' => $student->degree ?? $student->course ?? 'N/A',
            ],
            'time_in' => Carbon::parse($attendance->time_in)->format('h:i A'),
        ]);
    }
}