<?php

namespace App\Http\Controllers\Organizer;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Student;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Carbon\Carbon;

class OrganizerEventController extends Controller
{
    public function index(Request $request)
    {
        $userId = $request->user()->id;
        $search = $request->input('search');
        $tab = $request->input('tab', 'ongoing');
        $today = Carbon::today()->toDateString();

        // Base query strictly scoped to this organizer's created events
        $baseQuery = Event::where('user_id', $userId);

        // Tab count metrics scoped to organizer
        $counts = [
            'ongoing' => (clone $baseQuery)->where('approval_status', 'approved')->whereDate('event_date', '<=', $today)->where(fn($q) => $q->whereDate('event_end_date', '>=', $today)->orWhereNull('event_end_date'))->count(),
            'upcoming' => (clone $baseQuery)->where('approval_status', 'approved')->whereDate('event_date', '>', $today)->count(),
            'completed' => (clone $baseQuery)->where('approval_status', 'approved')->where(fn($q) => $q->whereDate('event_end_date', '<', $today)->orWhere(fn($sub) => $sub->whereNull('event_end_date')->whereDate('event_date', '<', $today)))->count(),
            'pending' => (clone $baseQuery)->where('approval_status', 'pending')->count(),
            'declined' => (clone $baseQuery)->where('approval_status', 'declined')->count(),
        ];

        $query = Event::where('user_id', $userId);

        if ($search) {
            $query->where(fn($q) => $q->where('title', 'like', "%{$search}%")->orWhere('location', 'like', "%{$search}%"));
        }

        switch ($tab) {
            case 'ongoing':
                $query->where('approval_status', 'approved')
                      ->whereDate('event_date', '<=', $today)
                      ->where(fn($q) => $q->whereDate('event_end_date', '>=', $today)->orWhereNull('event_end_date'));
                break;
            case 'upcoming':
                $query->where('approval_status', 'approved')->whereDate('event_date', '>', $today);
                break;
            case 'completed':
                $query->where('approval_status', 'approved')
                      ->where(fn($q) => $q->whereDate('event_end_date', '<', $today)->orWhere(fn($sub) => $sub->whereNull('event_end_date')->whereDate('event_date', '<', $today)));
                break;
            case 'pending':
                $query->where('approval_status', 'pending');
                break;
            case 'declined':
                $query->where('approval_status', 'declined');
                break;
        }

        $events = $query->latest('event_date')->paginate(10)->withQueryString();

        $events->getCollection()->transform(function ($event) {
            $event->event_id = $event->id;
            return $event;
        });

        // Get available student target audience sections
        $availableSections = Student::select('degree', 'year_section')
            ->distinct()
            ->get()
            ->map(fn($s) => trim("{$s->degree} - {$s->year_section}"))
            ->filter()
            ->unique()
            ->values();

        // Venue presets saved by this organizer
        $venues = Event::where('user_id', $userId)
            ->whereNotNull('location')
            ->select('location', 'latitude', 'longitude', 'radius_meters')
            ->distinct()
            ->take(5)
            ->get();

        return Inertia::render('organizer/Events', [
            'events' => $events,
            'counts' => $counts,
            'venues' => $venues,
            'availableSections' => $availableSections,
            'filters' => ['search' => $search, 'tab' => $tab],
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'location' => 'nullable|string',
            'is_geofenced' => 'boolean',
            'geofence_type' => 'in:radius,polygon',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'radius_meters' => 'integer',
            'geofence_polygon' => 'nullable|array',
            'target_scope' => 'in:all,section',
            'target_sections' => 'nullable|array',
            'event_date' => 'required|date',
            'event_end_date' => 'nullable|date|after_or_equal:event_date',
            'schedules' => 'nullable|array',
            'is_active' => 'boolean',
        ]);

        $validated['user_id'] = $request->user()->id;
        $validated['approval_status'] = 'pending'; // Requires Admin approval
        $validated['status'] = 'pending';

        Event::create($validated);

        return redirect()->back()->with('success', 'Event submitted for admin approval.');
    }

    public function update(Request $request, Event $event)
    {
        if ($event->user_id !== $request->user()->id) {
            abort(403, 'Unauthorized action.');
        }

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'location' => 'nullable|string',
            'is_geofenced' => 'boolean',
            'geofence_type' => 'in:radius,polygon',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'radius_meters' => 'integer',
            'geofence_polygon' => 'nullable|array',
            'target_scope' => 'in:all,section',
            'target_sections' => 'nullable|array',
            'event_date' => 'required|date',
            'event_end_date' => 'nullable|date|after_or_equal:event_date',
            'schedules' => 'nullable|array',
            'is_active' => 'boolean',
        ]);

        $validated['approval_status'] = 'pending'; // Re-triggers admin approval upon modification
        $event->update($validated);

        return redirect()->back()->with('success', 'Event updated and resubmitted for admin approval.');
    }

    public function destroy(Request $request, Event $event)
    {
        if ($event->user_id !== $request->user()->id) {
            abort(403, 'Unauthorized action.');
        }

        $event->delete();
        return redirect()->back()->with('success', 'Event deleted successfully.');
    }
}