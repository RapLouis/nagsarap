<?php

namespace App\Http\Controllers\Organizer;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Attendance;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Carbon\Carbon;

class OrganizerDashboardController extends Controller
{
    public function index(Request $request)
    {
        $userId = $request->user()->id;

        // 1. Ongoing Event created strictly by this organizer
        $ongoingEvent = Event::where('user_id', $userId)
            ->where('status', 'approved')
            ->whereDate('start_date', '<=', Carbon::today())
            ->whereDate('end_date', '>=', Carbon::today())
            ->with(['eventDays' => function ($q) {
                $q->whereDate('date', Carbon::today());
            }])
            ->first();

        // 2. Live attendance feed for the ongoing event
        $liveAttendance = [];
        if ($ongoingEvent) {
            $liveAttendance = Attendance::where('event_id', $ongoingEvent->id)
                ->whereDate('created_at', Carbon::today())
                ->with('student')
                ->latest()
                ->take(10)
                ->get();
        }

        // 3. Attendance Graph Metrics (Scoped strictly to events created by this organizer)
        $eventAnalytics = Event::where('user_id', $userId)
            ->withCount('attendances')
            ->get(['id', 'title', 'status', 'created_at'])
            ->map(fn($event) => [
                'id' => $event->id,
                'title' => $event->title,
                'status' => $event->status,
                'total_attendance' => $event->attendances_count ?? 0,
            ]);

        return Inertia::render('organizer/Dashboard', [
            'ongoingEvent' => $ongoingEvent,
            'liveAttendance' => $liveAttendance,
            'eventAnalytics' => $eventAnalytics,
        ]);
    }
}