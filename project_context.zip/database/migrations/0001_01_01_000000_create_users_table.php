<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();

            /*
            |--------------------------------------------------------------------------
            | Student Relationship (Column Only)
            |--------------------------------------------------------------------------
            */
            $table->unsignedInteger('student_id')
                ->nullable()
                ->unique();

            /*
            |--------------------------------------------------------------------------
            | User Account Information
            |--------------------------------------------------------------------------
            */
            $table->string('name');

            $table->string('email')
                ->unique();

            /*
            |--------------------------------------------------------------------------
            | Authentication Credentials & Password Flags
            |--------------------------------------------------------------------------
            */
            $table->timestamp('email_verified_at')
                ->nullable();

            $table->string('password');

            $table->boolean('must_change_password')
                ->default(false);

            $table->rememberToken();

            /*
            |--------------------------------------------------------------------------
            | System Roles & Organization Metadata
            |--------------------------------------------------------------------------
            */
            $table->enum('role', [
                'student',
                'organizer',
                'admin',
            ])->default('student');

            $table->string('organization_name')->nullable();
            $table->string('organization_position')->nullable();

            /*
            |--------------------------------------------------------------------------
            | Organizer Access Keys, Department, & Status Fields
            |--------------------------------------------------------------------------
            */
            $table->string('key_code')->nullable()->unique();
            $table->string('department')->nullable();
            $table->string('status')->default('active');

            $table->timestamps();

            /*
            |--------------------------------------------------------------------------
            | Indexes
            |--------------------------------------------------------------------------
            */
            $table->index('role');
            $table->index('key_code');
        });

        /*
        |--------------------------------------------------------------------------
        | Password Reset Tokens
        |--------------------------------------------------------------------------
        */
        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        /*
        |--------------------------------------------------------------------------
        | Active Sessions
        |--------------------------------------------------------------------------
        */
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();

            $table->foreignId('user_id')
                ->nullable()
                ->index();

            $table->string('ip_address', 45)
                ->nullable();

            $table->text('user_agent')
                ->nullable();

            $table->longText('payload');

            $table->integer('last_activity')
                ->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sessions');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('users');
    }
};