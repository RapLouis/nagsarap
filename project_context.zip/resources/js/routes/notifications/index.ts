import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StudentNotificationController::index
* @see app/Http/Controllers/StudentNotificationController.php:15
* @route '/notifications'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentNotificationController::index
* @see app/Http/Controllers/StudentNotificationController.php:15
* @route '/notifications'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentNotificationController::index
* @see app/Http/Controllers/StudentNotificationController.php:15
* @route '/notifications'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::index
* @see app/Http/Controllers/StudentNotificationController.php:15
* @route '/notifications'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::index
* @see app/Http/Controllers/StudentNotificationController.php:15
* @route '/notifications'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::index
* @see app/Http/Controllers/StudentNotificationController.php:15
* @route '/notifications'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::index
* @see app/Http/Controllers/StudentNotificationController.php:15
* @route '/notifications'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\StudentNotificationController::read
* @see app/Http/Controllers/StudentNotificationController.php:53
* @route '/notifications/{notification}/read'
*/
export const read = (args: { notification: number | { notification_id: number } } | [notification: number | { notification_id: number } ] | number | { notification_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: read.url(args, options),
    method: 'patch',
})

read.definition = {
    methods: ["patch"],
    url: '/notifications/{notification}/read',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\StudentNotificationController::read
* @see app/Http/Controllers/StudentNotificationController.php:53
* @route '/notifications/{notification}/read'
*/
read.url = (args: { notification: number | { notification_id: number } } | [notification: number | { notification_id: number } ] | number | { notification_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'notification_id' in args) {
        args = { notification: args.notification_id }
    }

    if (Array.isArray(args)) {
        args = {
            notification: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        notification: typeof args.notification === 'object'
        ? args.notification.notification_id
        : args.notification,
    }

    return read.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentNotificationController::read
* @see app/Http/Controllers/StudentNotificationController.php:53
* @route '/notifications/{notification}/read'
*/
read.patch = (args: { notification: number | { notification_id: number } } | [notification: number | { notification_id: number } ] | number | { notification_id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: read.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::read
* @see app/Http/Controllers/StudentNotificationController.php:53
* @route '/notifications/{notification}/read'
*/
const readForm = (args: { notification: number | { notification_id: number } } | [notification: number | { notification_id: number } ] | number | { notification_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: read.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::read
* @see app/Http/Controllers/StudentNotificationController.php:53
* @route '/notifications/{notification}/read'
*/
readForm.patch = (args: { notification: number | { notification_id: number } } | [notification: number | { notification_id: number } ] | number | { notification_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: read.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

read.form = readForm

/**
* @see \App\Http\Controllers\StudentNotificationController::readAll
* @see app/Http/Controllers/StudentNotificationController.php:74
* @route '/notifications/read-all'
*/
export const readAll = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: readAll.url(options),
    method: 'patch',
})

readAll.definition = {
    methods: ["patch"],
    url: '/notifications/read-all',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\StudentNotificationController::readAll
* @see app/Http/Controllers/StudentNotificationController.php:74
* @route '/notifications/read-all'
*/
readAll.url = (options?: RouteQueryOptions) => {
    return readAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentNotificationController::readAll
* @see app/Http/Controllers/StudentNotificationController.php:74
* @route '/notifications/read-all'
*/
readAll.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: readAll.url(options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::readAll
* @see app/Http/Controllers/StudentNotificationController.php:74
* @route '/notifications/read-all'
*/
const readAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: readAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentNotificationController::readAll
* @see app/Http/Controllers/StudentNotificationController.php:74
* @route '/notifications/read-all'
*/
readAllForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: readAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

readAll.form = readAllForm

const notifications = {
    index: Object.assign(index, index),
    read: Object.assign(read, read),
    readAll: Object.assign(readAll, readAll),
}

export default notifications