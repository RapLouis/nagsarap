import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/first-time-change-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(options),
    method: 'post',
})

update.form = updateForm

const firstChange = {
    update: Object.assign(update, update),
}

export default firstChange