import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::index
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:17
* @route '/admin/organizers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/organizers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::index
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:17
* @route '/admin/organizers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::index
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:17
* @route '/admin/organizers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::index
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:17
* @route '/admin/organizers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::index
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:17
* @route '/admin/organizers'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::index
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:17
* @route '/admin/organizers'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::index
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:17
* @route '/admin/organizers'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::store
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:43
* @route '/admin/organizers'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/organizers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::store
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:43
* @route '/admin/organizers'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::store
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:43
* @route '/admin/organizers'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::store
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:43
* @route '/admin/organizers'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::store
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:43
* @route '/admin/organizers'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::resetPassword
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:0
* @route '/admin/organizers/{user}/reset-password'
*/
export const resetPassword = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: resetPassword.url(args, options),
    method: 'put',
})

resetPassword.definition = {
    methods: ["put"],
    url: '/admin/organizers/{user}/reset-password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::resetPassword
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:0
* @route '/admin/organizers/{user}/reset-password'
*/
resetPassword.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: args.user,
    }

    return resetPassword.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::resetPassword
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:0
* @route '/admin/organizers/{user}/reset-password'
*/
resetPassword.put = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: resetPassword.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::resetPassword
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:0
* @route '/admin/organizers/{user}/reset-password'
*/
const resetPasswordForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resetPassword.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::resetPassword
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:0
* @route '/admin/organizers/{user}/reset-password'
*/
resetPasswordForm.put = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resetPassword.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

resetPassword.form = resetPasswordForm

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::destroy
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:95
* @route '/admin/organizers/{user}'
*/
export const destroy = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/organizers/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::destroy
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:95
* @route '/admin/organizers/{user}'
*/
destroy.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return destroy.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::destroy
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:95
* @route '/admin/organizers/{user}'
*/
destroy.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::destroy
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:95
* @route '/admin/organizers/{user}'
*/
const destroyForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\OrganizerManagementController::destroy
* @see app/Http/Controllers/Admin/OrganizerManagementController.php:95
* @route '/admin/organizers/{user}'
*/
destroyForm.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const organizers = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    resetPassword: Object.assign(resetPassword, resetPassword),
    destroy: Object.assign(destroy, destroy),
}

export default organizers