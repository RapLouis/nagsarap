import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Organizer\KioskController::search
* @see app/Http/Controllers/Organizer/KioskController.php:214
* @route '/organizer/students/search'
*/
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/organizer/students/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Organizer\KioskController::search
* @see app/Http/Controllers/Organizer/KioskController.php:214
* @route '/organizer/students/search'
*/
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\KioskController::search
* @see app/Http/Controllers/Organizer/KioskController.php:214
* @route '/organizer/students/search'
*/
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::search
* @see app/Http/Controllers/Organizer/KioskController.php:214
* @route '/organizer/students/search'
*/
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::search
* @see app/Http/Controllers/Organizer/KioskController.php:214
* @route '/organizer/students/search'
*/
const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::search
* @see app/Http/Controllers/Organizer/KioskController.php:214
* @route '/organizer/students/search'
*/
searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::search
* @see app/Http/Controllers/Organizer/KioskController.php:214
* @route '/organizer/students/search'
*/
searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

search.form = searchForm

const students = {
    search: Object.assign(search, search),
}

export default students