import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:23
* @route '/organizer/kiosk'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/organizer/kiosk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:23
* @route '/organizer/kiosk'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:23
* @route '/organizer/kiosk'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:23
* @route '/organizer/kiosk'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:23
* @route '/organizer/kiosk'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:23
* @route '/organizer/kiosk'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::index
* @see app/Http/Controllers/Organizer/KioskController.php:23
* @route '/organizer/kiosk'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Organizer\KioskController::challenge
* @see app/Http/Controllers/Organizer/KioskController.php:41
* @route '/organizer/kiosk/challenge'
*/
export const challenge = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: challenge.url(options),
    method: 'get',
})

challenge.definition = {
    methods: ["get","head"],
    url: '/organizer/kiosk/challenge',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Organizer\KioskController::challenge
* @see app/Http/Controllers/Organizer/KioskController.php:41
* @route '/organizer/kiosk/challenge'
*/
challenge.url = (options?: RouteQueryOptions) => {
    return challenge.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\KioskController::challenge
* @see app/Http/Controllers/Organizer/KioskController.php:41
* @route '/organizer/kiosk/challenge'
*/
challenge.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: challenge.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::challenge
* @see app/Http/Controllers/Organizer/KioskController.php:41
* @route '/organizer/kiosk/challenge'
*/
challenge.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: challenge.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::challenge
* @see app/Http/Controllers/Organizer/KioskController.php:41
* @route '/organizer/kiosk/challenge'
*/
const challengeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: challenge.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::challenge
* @see app/Http/Controllers/Organizer/KioskController.php:41
* @route '/organizer/kiosk/challenge'
*/
challengeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: challenge.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::challenge
* @see app/Http/Controllers/Organizer/KioskController.php:41
* @route '/organizer/kiosk/challenge'
*/
challengeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: challenge.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

challenge.form = challengeForm

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:68
* @route '/organizer/kiosk/verify'
*/
export const verify = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/organizer/kiosk/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:68
* @route '/organizer/kiosk/verify'
*/
verify.url = (options?: RouteQueryOptions) => {
    return verify.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:68
* @route '/organizer/kiosk/verify'
*/
verify.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:68
* @route '/organizer/kiosk/verify'
*/
const verifyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::verify
* @see app/Http/Controllers/Organizer/KioskController.php:68
* @route '/organizer/kiosk/verify'
*/
verifyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(options),
    method: 'post',
})

verify.form = verifyForm

/**
* @see \App\Http\Controllers\Organizer\KioskController::manualOverride
* @see app/Http/Controllers/Organizer/KioskController.php:232
* @route '/organizer/kiosk/manual-override'
*/
export const manualOverride = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: manualOverride.url(options),
    method: 'post',
})

manualOverride.definition = {
    methods: ["post"],
    url: '/organizer/kiosk/manual-override',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Organizer\KioskController::manualOverride
* @see app/Http/Controllers/Organizer/KioskController.php:232
* @route '/organizer/kiosk/manual-override'
*/
manualOverride.url = (options?: RouteQueryOptions) => {
    return manualOverride.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Organizer\KioskController::manualOverride
* @see app/Http/Controllers/Organizer/KioskController.php:232
* @route '/organizer/kiosk/manual-override'
*/
manualOverride.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: manualOverride.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::manualOverride
* @see app/Http/Controllers/Organizer/KioskController.php:232
* @route '/organizer/kiosk/manual-override'
*/
const manualOverrideForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: manualOverride.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Organizer\KioskController::manualOverride
* @see app/Http/Controllers/Organizer/KioskController.php:232
* @route '/organizer/kiosk/manual-override'
*/
manualOverrideForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: manualOverride.url(options),
    method: 'post',
})

manualOverride.form = manualOverrideForm

const kiosk = {
    index: Object.assign(index, index),
    challenge: Object.assign(challenge, challenge),
    verify: Object.assign(verify, verify),
    manualOverride: Object.assign(manualOverride, manualOverride),
}

export default kiosk