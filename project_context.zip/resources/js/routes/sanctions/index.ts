import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/sanctions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\StudentSanctionController::declare
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
export const declare = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: declare.url(options),
    method: 'post',
})

declare.definition = {
    methods: ["post"],
    url: '/sanctions/declare',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::declare
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
declare.url = (options?: RouteQueryOptions) => {
    return declare.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::declare
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
declare.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: declare.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::declare
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
const declareForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: declare.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::declare
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
declareForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: declare.url(options),
    method: 'post',
})

declare.form = declareForm

/**
* @see \App\Http\Controllers\StudentSanctionController::excuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
export const excuse = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: excuse.url(args, options),
    method: 'post',
})

excuse.definition = {
    methods: ["post"],
    url: '/sanctions/{sanction}/excuse',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::excuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
excuse.url = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sanction: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'sanction_id' in args) {
        args = { sanction: args.sanction_id }
    }

    if (Array.isArray(args)) {
        args = {
            sanction: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sanction: typeof args.sanction === 'object'
        ? args.sanction.sanction_id
        : args.sanction,
    }

    return excuse.definition.url
            .replace('{sanction}', parsedArgs.sanction.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::excuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
excuse.post = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: excuse.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::excuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
const excuseForm = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: excuse.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::excuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
excuseForm.post = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: excuse.url(args, options),
    method: 'post',
})

excuse.form = excuseForm

/**
* @see \App\Http\Controllers\StudentSanctionController::proof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
export const proof = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: proof.url(args, options),
    method: 'get',
})

proof.definition = {
    methods: ["get","head"],
    url: '/sanctions/{sanction}/proof',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::proof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
proof.url = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sanction: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'sanction_id' in args) {
        args = { sanction: args.sanction_id }
    }

    if (Array.isArray(args)) {
        args = {
            sanction: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sanction: typeof args.sanction === 'object'
        ? args.sanction.sanction_id
        : args.sanction,
    }

    return proof.definition.url
            .replace('{sanction}', parsedArgs.sanction.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::proof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
proof.get = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: proof.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::proof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
proof.head = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: proof.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::proof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
const proofForm = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: proof.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::proof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
proofForm.get = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: proof.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::proof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
proofForm.head = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: proof.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

proof.form = proofForm

const sanctions = {
    index: Object.assign(index, index),
    declare: Object.assign(declare, declare),
    excuse: Object.assign(excuse, excuse),
    proof: Object.assign(proof, proof),
}

export default sanctions