import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import verifyFaceE5d6b3 from './verify-face'
/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:18
* @route '/register/verify-face'
*/
export const verifyFace = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyFace.url(options),
    method: 'get',
})

verifyFace.definition = {
    methods: ["get","head"],
    url: '/register/verify-face',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:18
* @route '/register/verify-face'
*/
verifyFace.url = (options?: RouteQueryOptions) => {
    return verifyFace.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:18
* @route '/register/verify-face'
*/
verifyFace.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyFace.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:18
* @route '/register/verify-face'
*/
verifyFace.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyFace.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:18
* @route '/register/verify-face'
*/
const verifyFaceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: verifyFace.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:18
* @route '/register/verify-face'
*/
verifyFaceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: verifyFace.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaceVerificationController::verifyFace
* @see app/Http/Controllers/FaceVerificationController.php:18
* @route '/register/verify-face'
*/
verifyFaceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: verifyFace.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

verifyFace.form = verifyFaceForm

const register = {
    verifyFace: Object.assign(verifyFace, verifyFaceE5d6b3),
}

export default register