import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FirstTimePasswordController::show
* @see app/Http/Controllers/FirstTimePasswordController.php:14
* @route '/first-time-change-password'
*/
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/first-time-change-password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FirstTimePasswordController::show
* @see app/Http/Controllers/FirstTimePasswordController.php:14
* @route '/first-time-change-password'
*/
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FirstTimePasswordController::show
* @see app/Http/Controllers/FirstTimePasswordController.php:14
* @route '/first-time-change-password'
*/
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::show
* @see app/Http/Controllers/FirstTimePasswordController.php:14
* @route '/first-time-change-password'
*/
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::show
* @see app/Http/Controllers/FirstTimePasswordController.php:14
* @route '/first-time-change-password'
*/
const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::show
* @see app/Http/Controllers/FirstTimePasswordController.php:14
* @route '/first-time-change-password'
*/
showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::show
* @see app/Http/Controllers/FirstTimePasswordController.php:14
* @route '/first-time-change-password'
*/
showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/first-time-change-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FirstTimePasswordController::update
* @see app/Http/Controllers/FirstTimePasswordController.php:19
* @route '/first-time-change-password'
*/
updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(options),
    method: 'post',
})

update.form = updateForm

const FirstTimePasswordController = { show, update }

export default FirstTimePasswordController