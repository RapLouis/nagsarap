import StudentRegistrationController from './StudentRegistrationController'
import Api from './Api'
import FirstTimePasswordController from './FirstTimePasswordController'
import StudentDashboardController from './StudentDashboardController'
import StudentSanctionController from './StudentSanctionController'
import Admin from './Admin'
import EventController from './EventController'
import Organizer from './Organizer'
import FaceVerificationController from './FaceVerificationController'
import AttendanceController from './AttendanceController'
import StudentNotificationController from './StudentNotificationController'
import Settings from './Settings'

const Controllers = {
    StudentRegistrationController: Object.assign(StudentRegistrationController, StudentRegistrationController),
    Api: Object.assign(Api, Api),
    FirstTimePasswordController: Object.assign(FirstTimePasswordController, FirstTimePasswordController),
    StudentDashboardController: Object.assign(StudentDashboardController, StudentDashboardController),
    StudentSanctionController: Object.assign(StudentSanctionController, StudentSanctionController),
    Admin: Object.assign(Admin, Admin),
    EventController: Object.assign(EventController, EventController),
    Organizer: Object.assign(Organizer, Organizer),
    FaceVerificationController: Object.assign(FaceVerificationController, FaceVerificationController),
    AttendanceController: Object.assign(AttendanceController, AttendanceController),
    StudentNotificationController: Object.assign(StudentNotificationController, StudentNotificationController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers