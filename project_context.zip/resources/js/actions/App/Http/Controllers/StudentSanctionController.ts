import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/sanctions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::index
* @see app/Http/Controllers/StudentSanctionController.php:22
* @route '/sanctions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\StudentSanctionController::declareResolution
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
export const declareResolution = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: declareResolution.url(options),
    method: 'post',
})

declareResolution.definition = {
    methods: ["post"],
    url: '/sanctions/declare',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::declareResolution
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
declareResolution.url = (options?: RouteQueryOptions) => {
    return declareResolution.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::declareResolution
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
declareResolution.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: declareResolution.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::declareResolution
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
const declareResolutionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: declareResolution.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::declareResolution
* @see app/Http/Controllers/StudentSanctionController.php:119
* @route '/sanctions/declare'
*/
declareResolutionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: declareResolution.url(options),
    method: 'post',
})

declareResolution.form = declareResolutionForm

/**
* @see \App\Http\Controllers\StudentSanctionController::submitExcuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
export const submitExcuse = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitExcuse.url(args, options),
    method: 'post',
})

submitExcuse.definition = {
    methods: ["post"],
    url: '/sanctions/{sanction}/excuse',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::submitExcuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
submitExcuse.url = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sanction: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'sanction_id' in args) {
        args = { sanction: args.sanction_id }
    }

    if (Array.isArray(args)) {
        args = {
            sanction: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sanction: typeof args.sanction === 'object'
        ? args.sanction.sanction_id
        : args.sanction,
    }

    return submitExcuse.definition.url
            .replace('{sanction}', parsedArgs.sanction.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::submitExcuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
submitExcuse.post = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitExcuse.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::submitExcuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
const submitExcuseForm = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitExcuse.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::submitExcuse
* @see app/Http/Controllers/StudentSanctionController.php:144
* @route '/sanctions/{sanction}/excuse'
*/
submitExcuseForm.post = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitExcuse.url(args, options),
    method: 'post',
})

submitExcuse.form = submitExcuseForm

/**
* @see \App\Http\Controllers\StudentSanctionController::viewProof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
export const viewProof = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewProof.url(args, options),
    method: 'get',
})

viewProof.definition = {
    methods: ["get","head"],
    url: '/sanctions/{sanction}/proof',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentSanctionController::viewProof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
viewProof.url = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sanction: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'sanction_id' in args) {
        args = { sanction: args.sanction_id }
    }

    if (Array.isArray(args)) {
        args = {
            sanction: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sanction: typeof args.sanction === 'object'
        ? args.sanction.sanction_id
        : args.sanction,
    }

    return viewProof.definition.url
            .replace('{sanction}', parsedArgs.sanction.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentSanctionController::viewProof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
viewProof.get = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewProof.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::viewProof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
viewProof.head = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: viewProof.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::viewProof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
const viewProofForm = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: viewProof.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::viewProof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
viewProofForm.get = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: viewProof.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StudentSanctionController::viewProof
* @see app/Http/Controllers/StudentSanctionController.php:180
* @route '/sanctions/{sanction}/proof'
*/
viewProofForm.head = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: viewProof.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

viewProof.form = viewProofForm

const StudentSanctionController = { index, declareResolution, submitExcuse, viewProof }

export default StudentSanctionController