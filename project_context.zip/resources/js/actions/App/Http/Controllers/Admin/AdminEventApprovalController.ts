import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::approve
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:11
* @route '/admin/events/{event}/approve'
*/
export const approve = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/events/{event}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::approve
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:11
* @route '/admin/events/{event}/approve'
*/
approve.url = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'event_id' in args) {
        args = { event: args.event_id }
    }

    if (Array.isArray(args)) {
        args = {
            event: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        event: typeof args.event === 'object'
        ? args.event.event_id
        : args.event,
    }

    return approve.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::approve
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:11
* @route '/admin/events/{event}/approve'
*/
approve.post = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::approve
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:11
* @route '/admin/events/{event}/approve'
*/
const approveForm = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::approve
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:11
* @route '/admin/events/{event}/approve'
*/
approveForm.post = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

approve.form = approveForm

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::reject
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:17
* @route '/admin/events/{event}/reject'
*/
export const reject = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/events/{event}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::reject
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:17
* @route '/admin/events/{event}/reject'
*/
reject.url = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'event_id' in args) {
        args = { event: args.event_id }
    }

    if (Array.isArray(args)) {
        args = {
            event: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        event: typeof args.event === 'object'
        ? args.event.event_id
        : args.event,
    }

    return reject.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::reject
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:17
* @route '/admin/events/{event}/reject'
*/
reject.post = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::reject
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:17
* @route '/admin/events/{event}/reject'
*/
const rejectForm = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminEventApprovalController::reject
* @see app/Http/Controllers/Admin/AdminEventApprovalController.php:17
* @route '/admin/events/{event}/reject'
*/
rejectForm.post = (args: { event: number | { event_id: number } } | [event: number | { event_id: number } ] | number | { event_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

reject.form = rejectForm

const AdminEventApprovalController = { approve, reject }

export default AdminEventApprovalController