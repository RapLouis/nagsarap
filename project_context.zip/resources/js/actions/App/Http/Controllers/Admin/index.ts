import AdminDashboardController from './AdminDashboardController'
import StudentManagementController from './StudentManagementController'
import OrganizerManagementController from './OrganizerManagementController'
import ClearanceController from './ClearanceController'
import AdminSanctionController from './AdminSanctionController'
import AdminEventApprovalController from './AdminEventApprovalController'
import AnalyticsController from './AnalyticsController'

const Admin = {
    AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
    StudentManagementController: Object.assign(StudentManagementController, StudentManagementController),
    OrganizerManagementController: Object.assign(OrganizerManagementController, OrganizerManagementController),
    ClearanceController: Object.assign(ClearanceController, ClearanceController),
    AdminSanctionController: Object.assign(AdminSanctionController, AdminSanctionController),
    AdminEventApprovalController: Object.assign(AdminEventApprovalController, AdminEventApprovalController),
    AnalyticsController: Object.assign(AnalyticsController, AnalyticsController),
}

export default Admin