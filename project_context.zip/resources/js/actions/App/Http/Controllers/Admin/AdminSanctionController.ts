import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::index
* @see app/Http/Controllers/Admin/AdminSanctionController.php:23
* @route '/admin/sanctions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/sanctions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::index
* @see app/Http/Controllers/Admin/AdminSanctionController.php:23
* @route '/admin/sanctions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::index
* @see app/Http/Controllers/Admin/AdminSanctionController.php:23
* @route '/admin/sanctions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::index
* @see app/Http/Controllers/Admin/AdminSanctionController.php:23
* @route '/admin/sanctions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::index
* @see app/Http/Controllers/Admin/AdminSanctionController.php:23
* @route '/admin/sanctions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::index
* @see app/Http/Controllers/Admin/AdminSanctionController.php:23
* @route '/admin/sanctions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::index
* @see app/Http/Controllers/Admin/AdminSanctionController.php:23
* @route '/admin/sanctions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::updateFineRate
* @see app/Http/Controllers/Admin/AdminSanctionController.php:150
* @route '/admin/sanctions/fine-rate'
*/
export const updateFineRate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateFineRate.url(options),
    method: 'post',
})

updateFineRate.definition = {
    methods: ["post"],
    url: '/admin/sanctions/fine-rate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::updateFineRate
* @see app/Http/Controllers/Admin/AdminSanctionController.php:150
* @route '/admin/sanctions/fine-rate'
*/
updateFineRate.url = (options?: RouteQueryOptions) => {
    return updateFineRate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::updateFineRate
* @see app/Http/Controllers/Admin/AdminSanctionController.php:150
* @route '/admin/sanctions/fine-rate'
*/
updateFineRate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateFineRate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::updateFineRate
* @see app/Http/Controllers/Admin/AdminSanctionController.php:150
* @route '/admin/sanctions/fine-rate'
*/
const updateFineRateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateFineRate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::updateFineRate
* @see app/Http/Controllers/Admin/AdminSanctionController.php:150
* @route '/admin/sanctions/fine-rate'
*/
updateFineRateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateFineRate.url(options),
    method: 'post',
})

updateFineRate.form = updateFineRateForm

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyCash
* @see app/Http/Controllers/Admin/AdminSanctionController.php:168
* @route '/admin/sanctions/verify-cash'
*/
export const verifyCash = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyCash.url(options),
    method: 'post',
})

verifyCash.definition = {
    methods: ["post"],
    url: '/admin/sanctions/verify-cash',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyCash
* @see app/Http/Controllers/Admin/AdminSanctionController.php:168
* @route '/admin/sanctions/verify-cash'
*/
verifyCash.url = (options?: RouteQueryOptions) => {
    return verifyCash.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyCash
* @see app/Http/Controllers/Admin/AdminSanctionController.php:168
* @route '/admin/sanctions/verify-cash'
*/
verifyCash.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyCash.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyCash
* @see app/Http/Controllers/Admin/AdminSanctionController.php:168
* @route '/admin/sanctions/verify-cash'
*/
const verifyCashForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyCash.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyCash
* @see app/Http/Controllers/Admin/AdminSanctionController.php:168
* @route '/admin/sanctions/verify-cash'
*/
verifyCashForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyCash.url(options),
    method: 'post',
})

verifyCash.form = verifyCashForm

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyService
* @see app/Http/Controllers/Admin/AdminSanctionController.php:206
* @route '/admin/sanctions/verify-service'
*/
export const verifyService = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyService.url(options),
    method: 'post',
})

verifyService.definition = {
    methods: ["post"],
    url: '/admin/sanctions/verify-service',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyService
* @see app/Http/Controllers/Admin/AdminSanctionController.php:206
* @route '/admin/sanctions/verify-service'
*/
verifyService.url = (options?: RouteQueryOptions) => {
    return verifyService.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyService
* @see app/Http/Controllers/Admin/AdminSanctionController.php:206
* @route '/admin/sanctions/verify-service'
*/
verifyService.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyService.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyService
* @see app/Http/Controllers/Admin/AdminSanctionController.php:206
* @route '/admin/sanctions/verify-service'
*/
const verifyServiceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyService.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::verifyService
* @see app/Http/Controllers/Admin/AdminSanctionController.php:206
* @route '/admin/sanctions/verify-service'
*/
verifyServiceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verifyService.url(options),
    method: 'post',
})

verifyService.form = verifyServiceForm

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::reviewExcuse
* @see app/Http/Controllers/Admin/AdminSanctionController.php:242
* @route '/admin/sanctions/{sanction}/review-excuse'
*/
export const reviewExcuse = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reviewExcuse.url(args, options),
    method: 'post',
})

reviewExcuse.definition = {
    methods: ["post"],
    url: '/admin/sanctions/{sanction}/review-excuse',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::reviewExcuse
* @see app/Http/Controllers/Admin/AdminSanctionController.php:242
* @route '/admin/sanctions/{sanction}/review-excuse'
*/
reviewExcuse.url = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sanction: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'sanction_id' in args) {
        args = { sanction: args.sanction_id }
    }

    if (Array.isArray(args)) {
        args = {
            sanction: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sanction: typeof args.sanction === 'object'
        ? args.sanction.sanction_id
        : args.sanction,
    }

    return reviewExcuse.definition.url
            .replace('{sanction}', parsedArgs.sanction.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::reviewExcuse
* @see app/Http/Controllers/Admin/AdminSanctionController.php:242
* @route '/admin/sanctions/{sanction}/review-excuse'
*/
reviewExcuse.post = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reviewExcuse.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::reviewExcuse
* @see app/Http/Controllers/Admin/AdminSanctionController.php:242
* @route '/admin/sanctions/{sanction}/review-excuse'
*/
const reviewExcuseForm = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reviewExcuse.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdminSanctionController::reviewExcuse
* @see app/Http/Controllers/Admin/AdminSanctionController.php:242
* @route '/admin/sanctions/{sanction}/review-excuse'
*/
reviewExcuseForm.post = (args: { sanction: number | { sanction_id: number } } | [sanction: number | { sanction_id: number } ] | number | { sanction_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reviewExcuse.url(args, options),
    method: 'post',
})

reviewExcuse.form = reviewExcuseForm

const AdminSanctionController = { index, updateFineRate, verifyCash, verifyService, reviewExcuse }

export default AdminSanctionController