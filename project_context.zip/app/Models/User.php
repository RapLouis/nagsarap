<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'student_id',
        'name',
        'email',
        'password',
        'must_change_password',
        'role',
        'organization_name',
        'organization_position',
        'key_code',
        'department',
        'status',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'must_change_password' => 'boolean',
    ];

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class, 'student_id', 'student_id');
    }

    public function events(): HasMany
    {
        return $this->hasMany(Event::class, 'organizer_id', 'id');
    }

    public function isStudent(): bool { return $this->role === 'student'; }
    public function isOrganizer(): bool { return $this->role === 'organizer'; }
    public function isAdmin(): bool { return in_array($this->role, ['admin', 'super_admin'], true); }
}